import random

class Apple:
    def __init__(self, config, snake_body):
        self.block_size = config['block_size']
        self.reset(snake_body)

    def reset(self, snake_body):
        while True:
            self.x = random.randint(0, (config['board_width'] // self.block_size) - 1) * self.block_size
            self.y = random.randint(0, (config['board_height'] // self.block_size) - 1) * self.block_size
            if (self.x, self.y) not in snake_body:
                break

    def draw(self, screen):
        pygame.draw.rect(screen, (255, 0, 0), pygame.Rect(self.x, self.y, self.block_size, self.block_size))