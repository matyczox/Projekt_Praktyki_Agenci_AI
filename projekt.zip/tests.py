import unittest
from snake import SnakeGame
from game_state import GameState

class TestSnakeGame(unittest.TestCase):
    """
    Klasa testowa dla gry węża.
    """

    def test_start_game(self):
        """
        Testuje rozpoczęcie gry.
        """
        game = SnakeGame(None, None)
        self.assertEqual(game.state, GameState.START)

    def test_update_game(self):
        """
        Testuje aktualizację stanu gry.
        """
        game = SnakeGame(None, None)
        game.state = GameState.GAME
        game.snake = [(400, 300), (410, 300), (420, 300)]
        game.food = (430, 300)
        game.direction = 'right'
        game.update_game()
        self.assertEqual(game.snake[-1], (430, 300))

    def test_game_over(self):
        """
        Testuje ekran końca gry.
        """
        game = SnakeGame(None, None)
        game.state = GameState.GAME_OVER
        game.game_over()

if __name__ == '__main__':
    unittest.main()