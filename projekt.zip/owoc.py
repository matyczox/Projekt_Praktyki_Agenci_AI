class Owoc:
    def __init__(self, nazwa, waga):
        self.nazwa = nazwa
        self.waga = waga

    def __str__(self):
        return f"{self.nazwa} ({self.waga}g)"

class NiebieskiOwoc(Owoc):
    def __init__(self, nazwa, waga, kolor_nieba):
        super().__init__(nazwa, waga)
        self.kolor_nieba = kolor_nieba

    def __str__(self):
        return f"{self.nazwa} ({self.waga}g), Kolor nieba: {self.kolor_nieba}"