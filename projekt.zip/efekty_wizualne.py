import time

def wyswietl_blysk():
    print("✨💥 BŁYSK! 💥✨")
    time.sleep(0.5)  # Krótsze opóźnienie dla płynniejszego efektu

def wyswietl_animacje_zjedzenia():
    animacja = ["🍎", "🍊", "🍇", "🍌"]
    for owoc in animacja:
        print(f"Zjedzanie... {owoc}", end='\r')
        time.sleep(0.3)
    print("Zjadłeś owoc! 🎉")