import random
import pygame

class Food:
    def __init__(self, screen_width, screen_height, block_size):
        self.screen_width = screen_width
        self.screen_height = screen_height
        self.block_size = block_size
        self.position = self.random_position()
        self.color = (255, 0, 0)  # Czerwony kolor jabłka

    def random_position(self):
        x = random.randint(0, (self.screen_width - self.block_size) // self.block_size) * self.block_size
        y = random.randint(0, (self.screen_height - self.block_size) // self.block_size) * self.block_size
        return (x, y)

    def draw(self, screen):
        pygame.draw.rect(screen, self.color, pygame.Rect(self.position[0], self.position[1], self.block_size, self.block_size))

    def respawn(self):
        self.position = self.random_position()