import random

def generate_random_point():
    """
    Generuje losowy punkt na ekranie.
    """
    return (random.randint(0, 790) // 10 * 10, random.randint(0, 590) // 10 * 10)