import random

def generate_random_food_position(width, height, snake_body):
    while True:
        x = random.randint(0, (width - 10) // 10) * 10
        y = random.randint(0, (height - 10) // 10) * 10
        if (x, y) not in snake_body:
            return (x, y)