import pygame
from game_state import GameState
from utils import generate_random_point

class SnakeGame:
    """
    Klasa reprezentująca grę węża.
    """

    def __init__(self, screen, clock):
        """
        Inicjalizuje grę.

        :param screen: Ekran gry.
        :param clock: Zegar gry.
        """
        self.screen = screen
        self.clock = clock
        self.state = GameState.START
        self.snake = [(400, 300), (410, 300), (420, 300)]
        self.food = generate_random_point()
        self.direction = 'right'

    def run(self):
        """
        Uruchamia grę.
        """
        while True:
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    return
                elif event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_UP and self.direction != 'down':
                        self.direction = 'up'
                    elif event.key == pygame.K_DOWN and self.direction != 'up':
                        self.direction = 'down'
                    elif event.key == pygame.K_LEFT and self.direction != 'right':
                        self.direction = 'left'
                    elif event.key == pygame.K_RIGHT and self.direction != 'left':
                        self.direction = 'right'

            if self.state == GameState.START:
                self.start_game()
            elif self.state == GameState.GAME:
                self.update_game()
            elif self.state == GameState.GAME_OVER:
                self.game_over()

            self.draw_screen()
            pygame.display.flip()
            self.clock.tick(10)

    def start_game(self):
        """
        Rozpoczyna grę.
        """
        self.state = GameState.GAME

    def update_game(self):
        """
        Aktualizuje stan gry.
        """
        head = self.snake[-1]
        if self.direction == 'up':
            new_head = (head[0], head[1] - 10)
        elif self.direction == 'down':
            new_head = (head[0], head[1] + 10)
        elif self.direction == 'left':
            new_head = (head[0] - 10, head[1])
        elif self.direction == 'right':
            new_head = (head[0] + 10, head[1])

        self.snake.append(new_head)

        if self.food == new_head:
            self.food = generate_random_point()
        else:
            self.snake.pop(0)

        if (new_head[0] < 0 or new_head[0] >= 800 or
                new_head[1] < 0 or new_head[1] >= 600 or
                new_head in self.snake[:-1]):
            self.state = GameState.GAME_OVER

    def game_over(self):
        """
        Wyświetla ekran końca gry.
        """
        font = pygame.font.Font(None, 36)
        text = font.render("Game Over", True, (255, 255, 255))
        text_rect = text.get_rect(center=(400, 300))
        self.screen.fill((0, 0, 0))
        self.screen.blit(text, text_rect)

    def draw_screen(self):
        """
        Rysuje ekran gry.
        """
        self.screen.fill((0, 0, 0))
        for x, y in self.snake:
            pygame.draw.rect(self.screen, (255, 255, 255), (x, y, 10, 10))
        pygame.draw.rect(self.screen, (255, 0, 0), (self.food[0], self.food[1], 10, 10))