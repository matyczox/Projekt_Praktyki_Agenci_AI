import pygame

class Snake:
    def __init__(self):
        self.body = [(100, 50), (90, 50), (80, 50)]
        self.direction = pygame.K_RIGHT
        self.grow_flag = False

    @property
    def head(self):
        return self.body[0]

    def change_direction(self, key):
        if key == pygame.K_UP and self.direction != pygame.K_DOWN:
            self.direction = key
        elif key == pygame.K_DOWN and self.direction != pygame.K_UP:
            self.direction = key
        elif key == pygame.K_LEFT and self.direction != pygame.K_RIGHT:
            self.direction = key
        elif key == pygame.K_RIGHT and self.direction != pygame.K_LEFT:
            self.direction = key

    def move(self):
        x, y = self.body[0]
        if self.direction == pygame.K_UP:
            y -= 10
        elif self.direction == pygame.K_DOWN:
            y += 10
        elif self.direction == pygame.K_LEFT:
            x -= 10
        elif self.direction == pygame.K_RIGHT:
            x += 10

        new_head = (x, y)
        self.body.insert(0, new_head)

        if not self.grow_flag:
            self.body.pop()
        else:
            self.grow_flag = False

    def grow(self):
        self.grow_flag = True