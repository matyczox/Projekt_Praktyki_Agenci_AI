import random

class Snake:
    def __init__(self, config):
        self.body = [(config['snake_start_x'], config['snake_start_y'])]
        self.direction = 'RIGHT'
        self.config = config

    def move(self):
        head_x, head_y = self.body[0]

        if self.direction == 'UP':
            new_head = (head_x, head_y - self.config['block_size'])
        elif self.direction == 'DOWN':
            new_head = (head_x, head_y + self.config['block_size'])
        elif self.direction == 'LEFT':
            new_head = (head_x - self.config['block_size'], head_y)
        elif self.direction == 'RIGHT':
            new_head = (head_x + self.config['block_size'], head_y)

        self.body.insert(0, new_head)
        self.body.pop()

    def change_direction(self, key):
        if key == pygame.K_UP and self.direction != 'DOWN':
            self.direction = 'UP'
        elif key == pygame.K_DOWN and self.direction != 'UP':
            self.direction = 'DOWN'
        elif key == pygame.K_LEFT and self.direction != 'RIGHT':
            self.direction = 'LEFT'
        elif key == pygame.K_RIGHT and self.direction != 'LEFT':
            self.direction = 'RIGHT'

    def grow(self):
        tail = self.body[-1]
        if self.direction == 'UP':
            new_tail = (tail[0], tail[1] + self.config['block_size'])
        elif self.direction == 'DOWN':
            new_tail = (tail[0], tail[1] - self.config['block_size'])
        elif self.direction == 'LEFT':
            new_tail = (tail[0] + self.config['block_size'], tail[1])
        elif self.direction == 'RIGHT':
            new_tail = (tail[0] - self.config['block_size'], tail[1])

        self.body.append(new_tail)

    def draw(self, screen):
        for segment in self.body:
            pygame.draw.rect(screen, (0, 255, 0), pygame.Rect(segment[0], segment[1], self.config['block_size'], self.config['block_size']))

    def collides_with_wall(self):
        head_x, head_y = self.body[0]
        return head_x < 0 or head_x >= self.config['board_width'] or head_y < 0 or head_y >= self.config['board_height']

    def collides_with_self(self):
        return len(set(self.body)) != len(self.body)

    def eats_apple(self, apple):
        return self.body[0] == (apple.x, apple.y)

    def reset(self):
        self.body = [(self.config['snake_start_x'], self.config['snake_start_y'])]
        self.direction = 'RIGHT'