import pygame
from snake import Snake
from utils import generate_random_food_position

class SnakeGame:
    def __init__(self, width=640, height=480):
        self.width = width
        self.height = height
        self.screen = pygame.display.set_mode((width, height))
        pygame.display.set_caption("Snake Game")
        self.clock = pygame.time.Clock()
        self.snake = Snake()
        self.food_position = generate_random_food_position(self.width, self.height, self.snake.body)
        self.score = 0

    def run(self):
        running = True
        while running:
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    running = False
                elif event.type == pygame.KEYDOWN:
                    self.snake.change_direction(event.key)

            self.update()
            self.draw()

            if self.check_collision():
                running = False

            self.clock.tick(10)

        print(f"Game Over! Your score: {self.score}")

    def update(self):
        self.snake.move()
        if self.snake.head == self.food_position:
            self.snake.grow()
            self.food_position = generate_random_food_position(self.width, self.height, self.snake.body)
            self.score += 1

    def draw(self):
        self.screen.fill((0, 0, 0))
        for segment in self.snake.body:
            pygame.draw.rect(self.screen, (0, 255, 0), pygame.Rect(segment[0], segment[1], 10, 10))
        pygame.draw.rect(self.screen, (255, 0, 0), pygame.Rect(self.food_position[0], self.food_position[1], 10, 10))
        pygame.display.flip()

    def check_collision(self):
        if (self.snake.head[0] < 0 or self.snake.head[0] >= self.width or
            self.snake.head[1] < 0 or self.snake.head[1] >= self.height):
            return True
        for segment in self.snake.body[1:]:
            if self.snake.head == segment:
                return True
        return False