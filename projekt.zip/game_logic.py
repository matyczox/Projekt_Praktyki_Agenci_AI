import pygame
import random

class Game:
    def __init__(self, screen):
        self.screen = screen
        self.snake_pos = [100, 50]
        self.snake_body = [[100, 50], [90, 50], [80, 50]]
        self.food_pos = self.spawn_food()
        self.food_spawn = True
        self.direction = 'RIGHT'
        self.change_to = self.direction
        self.score = 0

    def spawn_food(self):
        return [random.randrange(1, (self.screen.get_width()//10)) * 10,
                random.randrange(1, (self.screen.get_height()//10)) * 10]

    def handle_key_event(self, key):
        if key == pygame.K_UP:
            self.change_to = 'UP'
        elif key == pygame.K_DOWN:
            self.change_to = 'DOWN'
        elif key == pygame.K_LEFT:
            self.change_to = 'LEFT'
        elif key == pygame.K_RIGHT:
            self.change_to = 'RIGHT'

    def update_direction(self):
        if self.change_to == 'UP' and not self.direction == 'DOWN':
            self.direction = 'UP'
        if self.change_to == 'DOWN' and not self.direction == 'UP':
            self.direction = 'DOWN'
        if self.change_to == 'LEFT' and not self.direction == 'RIGHT':
            self.direction = 'LEFT'
        if self.change_to == 'RIGHT' and not self.direction == 'LEFT':
            self.direction = 'RIGHT'

    def move_snake(self):
        if self.direction == 'UP':
            self.snake_pos[1] -= 10
        elif self.direction == 'DOWN':
            self.snake_pos[1] += 10
        elif self.direction == 'LEFT':
            self.snake_pos[0] -= 10
        elif self.direction == 'RIGHT':
            self.snake_pos[0] += 10

        self.snake_body.insert(0, list(self.snake_pos))
        if self.snake_pos == self.food_pos:
            self.score += 1
            self.food_spawn = False
        else:
            self.snake_body.pop()

    def check_collision(self):
        if (self.snake_pos[0] < 0 or self.snake_pos[0] >= self.screen.get_width() or
            self.snake_pos[1] < 0 or self.snake_pos[1] >= self.screen.get_height()):
            return True
        for block in self.snake_body[1:]:
            if self.snake_pos == block:
                return True
        return False

    def update(self):
        self.update_direction()
        self.move_snake()
        if not self.food_spawn:
            self.food_pos = self.spawn_food()
        self.food_spawn = True
        if self.check_collision():
            pygame.quit()

    def draw(self):
        for pos in self.snake_body:
            pygame.draw.rect(self.screen, (0, 255, 0), pygame.Rect(pos[0], pos[1], 10, 10))
        pygame.draw.rect(self.screen, (255, 0, 0), pygame.Rect(self.food_pos[0], self.food_pos[1], 10, 10))

        font = pygame.font.SysFont('monaco', 24)
        score_text = font.render(f'Score: {self.score}', True, (255, 255, 255))
        self.screen.blit(score_text, (10, 10))