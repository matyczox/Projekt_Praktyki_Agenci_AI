import pygame
from snake import Snake
from apple import Apple
from board import Board
import json

# Load configuration from config.json
with open('config.json', 'r') as file:
    config = json.load(file)

def main():
    pygame.init()
    screen = pygame.display.set_mode((config['board_width'], config['board_height']))
    clock = pygame.time.Clock()

    snake = Snake(config)
    apple = Apple(config, snake.body)
    board = Board(screen, config)

    running = True
    game_over = False

    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.KEYDOWN and not game_over:
                snake.change_direction(event.key)
            elif event.type == pygame.KEYDOWN and game_over and event.key == pygame.K_r:
                snake.reset()
                apple.reset(snake.body)
                board.score = 0
                game_over = False

        if not game_over:
            snake.move()
            if snake.collides_with_wall() or snake.collides_with_self():
                game_over = True
            if snake.eats_apple(apple):
                board.score += config['points_per_apple']
                apple.reset(snake.body)
                snake.grow()

        screen.fill((0, 0, 0))
        snake.draw(screen)
        apple.draw(screen)
        board.draw_score()
        pygame.display.flip()
        clock.tick(config['initial_speed'] + (board.score // 10))

    pygame.quit()

if __name__ == "__main__":
    main()