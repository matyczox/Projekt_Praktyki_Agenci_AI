import random
from gra import dodaj_nowy_owoc, zjedz_owoc
from efekty_wizualne import wyswietl_blysk, wyswietl_animacje_zjedzenia
from owoc import Owoc, NiebieskiOwoc

class Gra:
    def __init__(self):
        self.owoce = []
        self.punkty = 0
        self.poziom_trudnosci = 1

    def dodaj_owoc(self):
        nowy_owoc = dodaj_nowy_owoc(self.poziom_trudnosci)
        self.owoce.append(nowy_owoc)
        print(f"Dodano owoc: {nowy_owoc}")

    def zjedz_wybrany_owoc(self, indeks):
        try:
            indeks = int(indeks)
            owoc_do_zjedzenia = self.owoce.pop(indeks)
            punkty = zjedz_owoc(owoc_do_zjedzenia, self.poziom_trudnosci)
            self.punkty += punkty
            wyswietl_animacje_zjedzenia()
        except (ValueError, IndexError):
            print("Nieprawidłowy indeks!")

    def przyspiesz(self):
        self.poziom_trudnosci += 1
        print(f"Poziom trudności zwiększony do {self.poziom_trudnosci}.")

    def wyswietl_owoce(self):
        if not self.owoce:
            print("Brak dostępnych owoców.")
        else:
            for i, owoc in enumerate(self.owoce):
                print(f"{i}: {owoc}")

    def wyswietl_punkty(self):
        print(f"Twoje punkty: {self.punkty}")

def main():
    gra = Gra()
    while True:
        print("\nMenu:")
        print("1. Dodaj nowy owoc")
        print("2. Zjedz owoc")
        print("3. Przyspiesz grę")
        print("4. Wyświetl dostępne owoce")
        print("5. Wyświetl punkty")
        print("6. Wyjdź z gry")

        wybor = input("Wybierz opcję: ")

        if wybor == '1':
            gra.dodaj_owoc()
        elif wybor == '2':
            indeks = input("Podaj indeks owoca do zjedzenia: ")
            gra.zjedz_wybrany_owoc(indeks)
        elif wybor == '3':
            gra.przyspiesz()
        elif wybor == '4':
            gra.wyswietl_owoce()
        elif wybor == '5':
            gra.wyswietl_punkty()
        elif wybor == '6':
            print("Dziękujemy za grę!")
            break
        else:
            print("Nieprawidłowy wybór, spróbuj ponownie.")

if __name__ == "__main__":
    main()