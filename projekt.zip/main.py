import pygame
from snake_game import SnakeGame

def init_game():
    pygame.init()
    game = SnakeGame(width=640, height=480)
    game.run()
    pygame.quit()

if __name__ == "__main__":
    init_game()