import pygame
from snake import SnakeGame
from game_state import GameState

def main():
    """
    Główna funkcja programu, uruchamia grę.
    """
    pygame.init()
    screen = pygame.display.set_mode((800, 600))
    clock = pygame.time.Clock()

    game = SnakeGame(screen, clock)
    game.run()

if __name__ == "__main__":
    main()