# Snake Game

## Opis gry
Gra w Snake to klasyczna gra, w której gracz steruje wężem, który porusza się po planszy. Celem jest zjadanie jedzenia, co powoduje wzrost długości węża. Gra kończy się, gdy wąż uderzy w ścianę lub sam w siebie.

## Wymagania
Aby uruchomić grę, potrzebujesz mieć zainstalowany Python oraz bibliotekę `pygame`. Możesz zainstalować wymagane biblioteki za pomocą polecenia: