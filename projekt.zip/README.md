# Gra Snake w Pythonie

## Opis
Gra Snake to klasyczna gra, w której gracz steruje wężem, który porusza się po planszy. Celem gry jest zjedzenie jabłek, co powoduje wzrost węża i dodanie punktów. Gra kończy się, gdy wąż zderza się ze ścianą planszy lub ze sobą.

## Uruchomienie
1. Upewnij się, że masz zainstalowane Python i bibliotekę `pygame`. Możesz ją zainstalować za pomocą polecenia: