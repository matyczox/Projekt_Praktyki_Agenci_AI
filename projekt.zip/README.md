# Gra Owoce

## Opis Projektu

Gra Owoce to prosty program konsolowy napisany w Pythonie, który pozwala graczowi na dodawanie i zjedzanie owoców. Gracz może również przyspieszać gre, co wpływa na trudność gry.

## Funkcjonalności

1. **Dodawanie Owoców**: Losowo generowane są nowe owoce, które można dodać do listy dostępnych owoców.
2. **Zjedzanie Owoców**: Gracz może zjeść dowolny dostępny owoc i zdobywać punkty proporcjonalnie do wagi owocu.
3. **Przyspieszanie Gry**: Zwiększa poziom trudności gry, co wpływa na losowanie wag owoców.

## Struktura Katalogów

- `main.py`: Plik główny zawierający logikę gry i funkcje do implementacji.
- `owoc.py`: Definicja klasy Owoc, w tym nowego typu owocu "Niebieski Owoc".
- `gra.py`: Logika gry, w tym funkcje `dodaj_nowy_owoc()`, `zjedz_owoc()` i `przyspiesz()`.
- `efekty_wizualne.py`: Funkcje do wyświetlania efektów wizualnych, takich jak błysk lub animacja.
- `requirements.txt`: Lista wymaganych bibliotek i technologii.

## Instrukcje Uruchomienia

1. **Instalacja Wymagań**:
   Upewnij się, że masz zainstalowany Python 3.x. Następnie zainstaluj wszystkie wymagane biblioteki z pliku `requirements.txt`: