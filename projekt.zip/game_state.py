class GameState:
    """
    Klasa reprezentująca stany gry.
    """

    START = 'start'
    GAME = 'game'
    GAME_OVER = 'game_over'