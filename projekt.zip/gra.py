import random
from owoc import Owoc, NiebieskiOwoc

def dodaj_nowy_owoc(poziom_trudnosci):
    owoce = ["jabłko", "banan", "gruszka", "pomarańcza"]
    wagi = [100 * poziom_trudnosci, 150 * poziom_trudnosci, 200 * poziom_trudnosci, 250 * poziom_trudnosci]
    kolor_nieba = random.choice(["niebieski", "zielony", "fioletowy"])
    
    if random.random() < 0.3:  # 30% szansy na NiebieskiOwoc
        return NiebieskiOwoc(random.choice(owoce), random.choice(wagi), kolor_nieba)
    else:
        return Owoc(random.choice(owoce), random.choice(wagi))

def zjedz_owoc(owoc, poziom_trudnosci):
    punkty = owoc.waga // (10 * poziom_trudnosci)
    print(f"Zjadłeś {owoc} i zdobywasz {punkty} punktów!")
    return punkty