import random
from typing import Tuple

class Food:
    def __init__(self) -> None:
        self.position: Tuple[int, int] = (0, 0)
        self.special_position: Tuple[int, int] = (0, 0)
        self.randomize_positions()

    def randomize_positions(self) -> None:
        """
        Randomizes the positions of the food and special food.
        """
        self.position = (random.randint(1, 59) * 10, random.randint(1, 59) * 10)
        self.special_position = (random.randint(1, 59) * 10, random.randint(1, 59) * 10)

    def is_special(self, position: Tuple[int, int]) -> bool:
        """
        Checks if the given position is a special food.
        """
        return position == self.special_position