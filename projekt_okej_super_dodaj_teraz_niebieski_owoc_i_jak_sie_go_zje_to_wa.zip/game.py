import pygame
from snake import Snake
from food import Food

class Game:
    def __init__(self) -> None:
        self.width: int = 600
        self.height: int = 600
        self.screen: pygame.Surface = pygame.display.set_mode((self.width, self.height))
        self.clock: pygame.time.Clock = pygame.time.Clock()
        self.snake: Snake = Snake()
        self.food: Food = Food()
        self.score: int = 0
        self.running: bool = True

    def run(self) -> None:
        """
        Main game loop.
        Handles events, updates the game state, and renders the screen.
        """
        while self.running:
            self.handle_events()
            self.update()
            self.render()

    def handle_events(self) -> None:
        """
        Handles user input events.
        """
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                self.running = False
            elif event.type == pygame.KEYDOWN:
                if event.key == pygame.K_UP:
                    self.snake.change_direction('UP')
                elif event.key == pygame.K_DOWN:
                    self.snake.change_direction('DOWN')
                elif event.key == pygame.K_LEFT:
                    self.snake.change_direction('LEFT')
                elif event.key == pygame.K_RIGHT:
                    self.snake.change_direction('RIGHT')

    def update(self) -> None:
        """
        Updates the game state.
        Handles snake movement, collision detection, and score updating.
        """
        self.snake.move()
        head = self.snake.body[0]

        if (head[0] >= self.width or head[0] < 0 or
            head[1] >= self.height or head[1] < 0):
            self.game_over()

        for segment in self.snake.body[1:]:
            if head == segment:
                self.game_over()

        if head == self.food.position:
            self.score += 1
            self.snake.length += 1
            self.food.randomize_positions()
            if self.score % 10 == 0:
                self.snake.speed += 5

        if head == self.food.special_position:
            self.score += 2
            self.snake.length += 1
            self.snake.boost_speed()
            self.food.randomize_positions()

    def render(self) -> None:
        """
        Renders the game screen.
        Draws the snake, food, special food, and score.
        """
        self.screen.fill((0, 0, 0))
        for segment in self.snake.body:
            pygame.draw.rect(self.screen, (0, 255, 0), pygame.Rect(segment[0], segment[1], 10, 10))

        pygame.draw.rect(self.screen, (255, 0, 0), pygame.Rect(self.food.position[0], self.food.position[1], 10, 10))
        pygame.draw.rect(self.screen, (0, 0, 255), pygame.Rect(self.food.special_position[0], self.food.special_position[1], 10, 10))

        font = pygame.font.SysFont(None, 36)
        score_text = font.render(f'Score: {self.score}', True, (255, 255, 255))
        self.screen.blit(score_text, (10, 10))

        pygame.display.flip()
        self.clock.tick(self.snake.speed)

    def game_over(self) -> None:
        """
        Handles the game over state.
        Resets the game and asks for a restart.
        """
        font = pygame.font.SysFont(None, 72)
        game_over_text = font.render('Game Over', True, (255, 0, 0))
        self.screen.blit(game_over_text, (self.width // 4, self.height // 3))

        pygame.display.flip()
        pygame.time.wait(2000)

        restart = input("Do you want to restart? (y/n): ")
        if restart.lower() == 'y':
            self.snake = Snake()
            self.food.randomize_positions()
            self.score = 0
        else:
            self.running = False