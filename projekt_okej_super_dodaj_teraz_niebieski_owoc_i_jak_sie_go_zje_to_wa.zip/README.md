# Gra Snake w Pythonie z użyciem biblioteki pygame

## Opis projektu

Gra Snake to klasyczna gra, w której gracz steruje wężem, który porusza się po siatce. Celem gry jest zjedzenie jabłek i niebieskich owoców, które dają dodatkowe punkty i przyspieszają węża. Gra kończy się, gdy wąż uderza w granicę planszy lub sam siebie.

## Wymagane biblioteki

- pygame
- random

## Instalacja

1. Zainstaluj wymagane biblioteki: