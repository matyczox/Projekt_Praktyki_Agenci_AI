from typing import List, Tuple

class Snake:
    def __init__(self) -> None:
        self.body: List[Tuple[int, int]] = [(300, 300), (290, 300), (280, 300)]
        self.direction: str = 'RIGHT'
        self.speed: int = 15
        self.length: int = 3
        self.is_speed_boosted: bool = False

    def move(self) -> None:
        """
        Moves the snake in the current direction.
        """
        head_x, head_y = self.body[0]

        if self.direction == 'UP':
            new_head = (head_x, head_y - 10)
        elif self.direction == 'DOWN':
            new_head = (head_x, head_y + 10)
        elif self.direction == 'LEFT':
            new_head = (head_x - 10, head_y)
        elif self.direction == 'RIGHT':
            new_head = (head_x + 10, head_y)

        self.body.insert(0, new_head)
        if len(self.body) > self.length:
            self.body.pop()

    def change_direction(self, direction: str) -> None:
        """
        Changes the direction of the snake.
        """
        if direction == 'UP' and self.direction != 'DOWN':
            self.direction = 'UP'
        elif direction == 'DOWN' and self.direction != 'UP':
            self.direction = 'DOWN'
        elif direction == 'LEFT' and self.direction != 'RIGHT':
            self.direction = 'LEFT'
        elif direction == 'RIGHT' and self.direction != 'LEFT':
            self.direction = 'RIGHT'

    def boost_speed(self) -> None:
        """
        Boosts the speed of the snake.
        """
        self.speed = 30
        self.is_speed_boosted = True

    def reset_speed(self) -> None:
        """
        Resets the speed of the snake to normal.
        """
        self.speed = 15
        self.is_speed_boosted = False