# Game settings
SCREEN_WIDTH = 600
SCREEN_HEIGHT = 600
BACKGROUND_COLOR = (0, 0, 0)
BLOCK_SIZE = 20

# Snake settings
SNAKE_COLOR = (0, 255, 0)

# Food settings
FOOD_COLOR = (255, 0, 0)

# Font settings
FONT = None
FONT_SIZE = 36