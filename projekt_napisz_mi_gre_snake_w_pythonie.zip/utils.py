from settings import BLOCK_SIZE

def is_collision(head: tuple, body: list) -> bool:
    """
    Checks if the head of the snake collides with any part of its body or the food.
    """
    for segment in body[1:]:
        if head == segment:
            return True
    return False