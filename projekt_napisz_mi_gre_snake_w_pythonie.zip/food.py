import random
from typing import Tuple

class Food:
    """
    Class representing the Food in the game.
    Handles the generation of random positions for the food.
    """

    def __init__(self) -> None:
        self.position: Tuple[int, int] = (0, 0)
        self.randomize_position()

    def randomize_position(self) -> None:
        """
        Randomizes the position of the food within the grid.
        """
        self.position = (random.randint(0, 19), random.randint(0, 19))

    def get_position(self) -> Tuple[int, int]:
        """
        Returns the current position of the food.
        """
        return self.position