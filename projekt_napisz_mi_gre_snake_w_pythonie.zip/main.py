import pygame
from game import Game

def main() -> None:
    """
    Main entry point of the Snake game.
    Initializes Pygame and starts the game loop.
    """
    pygame.init()
    clock = pygame.time.Clock()
    game = Game()

    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.KEYDOWN:
                game.handle_key_event(event.key)

        game.update()
        game.render()
        clock.tick(10 + game.speed)  # Increase speed based on score

    pygame.quit()

if __name__ == "__main__":
    main()