import pygame
from snake import Snake
from food import Food
from settings import SCREEN_WIDTH, SCREEN_HEIGHT, BACKGROUND_COLOR, FONT, FONT_SIZE
from utils import is_collision

class Game:
    def __init__(self):
        self.screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))
        pygame.display.set_caption("Snake Game")
        self.clock = pygame.time.Clock()
        self.snake = Snake()
        self.food = Food()
        self.score = 0
        self.font = pygame.font.Font(FONT, FONT_SIZE)
        self.running = True

    def run(self):
        """
        Main game loop.
        Handles events, updates the game state, and renders the game.
        """
        while self.running:
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    self.running = False
                elif event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_UP:
                        self.snake.change_direction("UP")
                    if event.key == pygame.K_DOWN:
                        self.snake.change_direction("DOWN")
                    if event.key == pygame.K_LEFT:
                        self.snake.change_direction("LEFT")
                    if event.key == pygame.K_RIGHT:
                        self.snake.change_direction("RIGHT")
                    if event.key == pygame.K_r and not self.running:
                        self.restart_game()

            self.update()
            self.render()
            self.clock.tick(10 + (self.score // 10))

        pygame.quit()

    def update(self):
        """
        Updates the game state.
        Handles snake movement, collision detection, and score calculation.
        """
        self.snake.move()
        if is_collision(self.snake.body[0], self.food.position):
            self.snake.grow()
            self.food.respawn()
            self.score += 1

        if (self.snake.body[0][0] >= SCREEN_WIDTH or
            self.snake.body[0][0] < 0 or
            self.snake.body[0][1] >= SCREEN_HEIGHT or
            self.snake.body[0][1] < 0 or
            is_collision(self.snake.body[0], self.snake.body[1:])):
            self.running = False

    def render(self):
        """
        Renders the game on the screen.
        Draws the background, snake, food, and score.
        """
        self.screen.fill(BACKGROUND_COLOR)
        self.snake.draw(self.screen)
        self.food.draw(self.screen)
        self.show_score()
        pygame.display.flip()

    def show_score(self):
        """
        Displays the current score on the screen.
        """
        score_text = self.font.render(f"Score: {self.score}", True, (255, 255, 255))
        self.screen.blit(score_text, (10, 10))

    def restart_game(self):
        """
        Restarts the game by resetting the snake and food positions.
        """
        self.snake = Snake()
        self.food = Food()
        self.score = 0
        self.running = True