import pygame
from snake import Snake
from food import Food

class Game:
    """
    Class representing the game logic.
    Handles the game state, score, and rendering.
    """

    def __init__(self) -> None:
        self.screen = pygame.display.set_mode((600, 600))
        pygame.display.set_caption("Snake Game")
        self.clock = pygame.time.Clock()
        self.snake = Snake()
        self.food = Food()
        self.score: int = 0
        self.speed: int = 0

    def handle_key_event(self, key: int) -> None:
        """
        Handles keyboard events to change the snake's direction.
        """
        if key == pygame.K_UP:
            self.snake.change_direction((0, -1))
        elif key == pygame.K_DOWN:
            self.snake.change_direction((0, 1))
        elif key == pygame.K_LEFT:
            self.snake.change_direction((-1, 0))
        elif key == pygame.K_RIGHT:
            self.snake.change_direction((1, 0))

    def update(self) -> None:
        """
        Updates the game state.
        Moves the snake, checks for collisions, and handles food consumption.
        """
        self.snake.move()
        if self.snake.check_collision():
            self.restart_game()
        if self.snake.get_head_position() == self.food.get_position():
            self.snake.grow_snake()
            self.food.randomize_position()
            self.score += 1
            if self.score % 10 == 0:
                self.speed += 1

    def render(self) -> None:
        """
        Renders the game elements on the screen.
        Draws the snake, food, and score.
        """
        self.screen.fill((0, 0, 0))
        for segment in self.snake.body:
            pygame.draw.rect(self.screen, (0, 255, 0), pygame.Rect(segment[0] * 30, segment[1] * 30, 30, 30))
        pygame.draw.rect(self.screen, (255, 0, 0), pygame.Rect(self.food.get_position()[0] * 30, self.food.get_position()[1] * 30, 30, 30))
        font = pygame.font.SysFont(None, 36)
        score_text = font.render(f"Score: {self.score}", True, (255, 255, 255))
        self.screen.blit(score_text, (10, 10))
        pygame.display.flip()

    def restart_game(self) -> None:
        """
        Restarts the game by resetting the snake and score.
        """
        self.snake = Snake()
        self.food.randomize_position()
        self.score = 0
        self.speed = 0