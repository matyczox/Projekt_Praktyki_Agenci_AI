# Snake Game in Python

This is a simple implementation of the classic Snake game using the Pygame library.

## Requirements

- Python 3.x
- Pygame library (`pip install pygame`)

## How to Run

1. Clone or download this repository.
2. Open a terminal and navigate to the project directory.
3. Install the required dependencies: