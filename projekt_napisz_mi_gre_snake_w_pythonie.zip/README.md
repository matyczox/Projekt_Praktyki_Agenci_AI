# Snake Game

A simple implementation of the classic Snake game using Python and Pygame.

## Requirements

- Python 3.x
- Pygame library (`pip install pygame`)

## How to Run

1. Clone this repository or download the files.
2. Open a terminal and navigate to the directory containing the files.
3. Ensure you have Pygame installed by running `pip install pygame`.
4. Run the game using the command: