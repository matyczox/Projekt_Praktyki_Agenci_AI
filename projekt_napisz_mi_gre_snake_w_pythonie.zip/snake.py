from typing import List, Tuple

class Snake:
    """
    Class representing the Snake in the game.
    Handles movement, growth, and collision detection.
    """

    def __init__(self) -> None:
        self.body: List[Tuple[int, int]] = [(10, 10), (9, 10), (8, 10)]
        self.direction: Tuple[int, int] = (1, 0)
        self.grow: bool = False

    def move(self) -> None:
        """
        Moves the snake in the current direction.
        If grow is True, the snake grows by one segment.
        """
        head_x, head_y = self.body[0]
        dx, dy = self.direction
        new_head = (head_x + dx, head_y + dy)
        self.body.insert(0, new_head)

        if not self.grow:
            self.body.pop()
        else:
            self.grow = False

    def change_direction(self, direction: Tuple[int, int]) -> None:
        """
        Changes the direction of the snake.
        Ensures that the snake does not move backwards into itself.
        """
        dx, dy = direction
        if (dx, dy) != (-self.direction[0], -self.direction[1]):
            self.direction = direction

    def check_collision(self) -> bool:
        """
        Checks for collisions with the walls or itself.
        Returns True if a collision is detected.
        """
        head_x, head_y = self.body[0]
        return (head_x < 0 or head_x >= 20 or
                head_y < 0 or head_y >= 20 or
                self.body.count(self.body[0]) > 1)

    def grow_snake(self) -> None:
        """
        Sets the flag to grow the snake.
        """
        self.grow = True

    def get_head_position(self) -> Tuple[int, int]:
        """
        Returns the current position of the snake's head.
        """
        return self.body[0]