import pygame
from settings import BLOCK_SIZE, SNAKE_COLOR

class Snake:
    def __init__(self):
        self.body = [(100, 50), (90, 50), (80, 50)]
        self.direction = "RIGHT"
        self.change_to = self.direction

    def change_direction(self, direction: str):
        """
        Changes the direction of the snake if it's not opposite to the current direction.
        """
        if direction == "UP" and not self.direction == "DOWN":
            self.change_to = "UP"
        if direction == "DOWN" and not self.direction == "UP":
            self.change_to = "DOWN"
        if direction == "LEFT" and not self.direction == "RIGHT":
            self.change_to = "LEFT"
        if direction == "RIGHT" and not self.direction == "LEFT":
            self.change_to = "RIGHT"

    def move(self):
        """
        Moves the snake in the current direction.
        """
        head_x, head_y = self.body[0]
        if self.change_to == "UP":
            head_y -= BLOCK_SIZE
        if self.change_to == "DOWN":
            head_y += BLOCK_SIZE
        if self.change_to == "LEFT":
            head_x -= BLOCK_SIZE
        if self.change_to == "RIGHT":
            head_x += BLOCK_SIZE

        self.body.insert(0, (head_x, head_y))
        self.body.pop()

    def draw(self, surface: pygame.Surface):
        """
        Draws the snake on the given surface.
        """
        for segment in self.body:
            pygame.draw.rect(surface, SNAKE_COLOR, pygame.Rect(segment[0], segment[1], BLOCK_SIZE, BLOCK_SIZE))

    def grow(self):
        """
        Grows the snake by adding a new segment to its body.
        """
        tail_x, tail_y = self.body[-1]
        if self.direction == "UP":
            tail_y += BLOCK_SIZE
        if self.direction == "DOWN":
            tail_y -= BLOCK_SIZE
        if self.direction == "LEFT":
            tail_x += BLOCK_SIZE
        if self.direction == "RIGHT":
            tail_x -= BLOCK_SIZE

        self.body.append((tail_x, tail_y))